Android SDK Platform-Tools 是 Android SDK 的一个组件。它包含与 Android 平台进行交互的工具，主要是 adb 和 fastboot。

https://developer.android.google.cn/studio/releases/platform-tools?hl=zh-cn